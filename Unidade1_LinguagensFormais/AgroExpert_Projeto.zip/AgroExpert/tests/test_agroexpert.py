import unittest
from agroexpert import avaliar


class TestAgroExpert(unittest.TestCase):
    def test_solo_seco_sem_chuva(self):
        r = avaliar(20, 'nao', 25, 'medio', 'crescimento')
        self.assertEqual(r['decisao'], 'IRRIGACAO RECOMENDADA')
        self.assertEqual(len(r['regras']), 2)

    def test_solo_seco_com_chuva(self):
        r = avaliar(20, 'sim', 25, 'medio', 'crescimento')
        self.assertEqual(r['decisao'], 'AGUARDAR E REAVALIAR A CHUVA')

    def test_solo_umido(self):
        r = avaliar(55, 'nao', 25, 'medio', 'crescimento')
        self.assertEqual(r['decisao'], 'NAO IRRIGAR POR ENQUANTO')

    def test_alertas(self):
        r = avaliar(25, 'nao', 35, 'arenoso', 'inicial')
        self.assertTrue(r['fatos']['risco_perda_agua'])
        self.assertTrue(r['fatos']['planta_sensivel'])
        self.assertEqual(len(r['regras']), 4)

    def test_limite_30(self):
        self.assertFalse(avaliar(30, 'nao', 25, 'medio', 'adulta')['fatos']['solo_seco'])

    def test_entrada_invalida(self):
        with self.assertRaises(ValueError):
            avaliar(120, 'nao', 25, 'medio', 'adulta')


if __name__ == '__main__':
    unittest.main()
