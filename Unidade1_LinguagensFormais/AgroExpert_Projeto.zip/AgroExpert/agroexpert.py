"""AgroExpert: protótipo educativo de sistema especialista de irrigação."""


def avaliar(umidade, chuva, temperatura, solo, fase):
    """Aplica regras SE-ENTÃO e retorna decisão, fatos e explicações."""
    if not 0 <= umidade <= 100:
        raise ValueError('Umidade deve estar entre 0 e 100%.')
    if not -20 <= temperatura <= 60:
        raise ValueError('Temperatura deve estar entre -20 e 60 °C.')
    if chuva not in ('sim', 'nao'):
        raise ValueError('Chuva deve ser sim ou nao.')
    if solo not in ('arenoso', 'medio', 'argiloso'):
        raise ValueError('Tipo de solo inválido.')
    if fase not in ('inicial', 'crescimento', 'adulta'):
        raise ValueError('Fase inválida.')

    fatos = {'solo_seco': False, 'risco_perda_agua': False, 'planta_sensivel': False}
    regras = []

    # R1: gera um novo fato, usado pelas regras R4 e R5.
    if umidade < 30:
        fatos['solo_seco'] = True
        regras.append('R1: umidade abaixo de 30% -> solo seco')

    # R2 e R3: alertas complementares, sem alterar a decisão principal.
    if temperatura >= 32 and solo == 'arenoso':
        fatos['risco_perda_agua'] = True
        regras.append('R2: calor e solo arenoso -> atenção à perda de água')
    if fase == 'inicial':
        fatos['planta_sensivel'] = True
        regras.append('R3: fase inicial -> acompanhar a disponibilidade de água')

    # R4, R5 e R6: conclusões mutuamente exclusivas.
    if fatos['solo_seco'] and chuva == 'nao':
        decisao = 'IRRIGACAO RECOMENDADA'
        regras.append('R4: solo seco e sem previsão de chuva -> irrigar')
    elif fatos['solo_seco'] and chuva == 'sim':
        decisao = 'AGUARDAR E REAVALIAR A CHUVA'
        regras.append('R5: solo seco e previsão de chuva -> reavaliar')
    else:
        decisao = 'NAO IRRIGAR POR ENQUANTO'
        regras.append('R6: umidade igual ou acima de 30% -> não irrigar agora')

    return {'decisao': decisao, 'fatos': fatos, 'regras': regras}


def executar():
    print('=== AGROEXPERT ===')
    print('Sistema Especialista de Irrigação (protótipo educativo)')
    try:
        umidade = float(input('Umidade do solo (%): ').replace(',', '.'))
        temperatura = float(input('Temperatura (°C): ').replace(',', '.'))
        chuva = input('Há previsão de chuva? (sim/nao): ').strip().lower().replace('não', 'nao')
        print('Solo: 1-Arenoso  2-Médio  3-Argiloso')
        solo = {'1': 'arenoso', '2': 'medio', '3': 'argiloso'}.get(input('Escolha: ').strip(), '')
        print('Fase: 1-Inicial  2-Crescimento  3-Adulta')
        fase = {'1': 'inicial', '2': 'crescimento', '3': 'adulta'}.get(input('Escolha: ').strip(), '')
        resultado = avaliar(umidade, chuva, temperatura, solo, fase)
    except ValueError as erro:
        print('Erro:', erro)
        return
    print('\n=== RESULTADO ===')
    print('Decisão:', resultado['decisao'])
    print('Regras ativadas:')
    for regra in resultado['regras']:
        print(' -', regra)
    if resultado['fatos']['risco_perda_agua']:
        print('Alerta: calor e solo arenoso podem aumentar a perda de água.')
    if resultado['fatos']['planta_sensivel']:
        print('Alerta: acompanhar a disponibilidade de água na fase inicial.')
    print('\nAVISO: Limiares didáticos. Não usar para automatizar irrigação real.')


if __name__ == '__main__':
    executar()
