# AgroExpert — Sistema Especialista de Irrigação Inteligente

Projeto acadêmico em Python que simula recomendações de irrigação com base em regras **SE–ENTÃO** e **encadeamento para frente**.

## Problema e objetivo

Auxiliar, de forma educativa, a interpretação de dados simplificados de umidade do solo, previsão de chuva, temperatura, textura do solo e fase da planta. O programa recomenda irrigar, aguardar e reavaliar a chuva, ou não irrigar por enquanto.

## Como executar

Requer Python 3, sem bibliotecas externas.

```bash
python agroexpert.py
```

Para rodar os testes a partir da pasta principal:

```bash
python -m unittest discover -s tests -v
```

## Entradas

- Umidade do solo (%): 0 a 100
- Temperatura (°C): -20 a 60
- Previsão de chuva: sim/não
- Tipo de solo: arenoso, médio ou argiloso
- Fase da planta: inicial, crescimento ou adulta

## Base de conhecimento: seis regras

| Regra | SE | ENTÃO |
|---|---|---|
| R1 | Umidade < 30% | Registrar `solo_seco = True` |
| R2 | Temperatura >= 32°C e solo arenoso | Sinalizar risco de perda de água |
| R3 | Fase inicial | Sinalizar necessidade de acompanhamento |
| R4 | Solo seco e sem previsão de chuva | Recomendar irrigação |
| R5 | Solo seco e com previsão de chuva | Aguardar e reavaliar |
| R6 | Umidade >= 30% | Não irrigar por enquanto |

## Motor de inferência

O motor utiliza **encadeamento para frente**: recebe fatos informados pelo usuário, verifica R1 a R3 e cria novos fatos (`solo_seco`, `risco_perda_agua`, `planta_sensivel`). Em seguida, aplica R4, R5 ou R6 para produzir a decisão principal. O programa lista as regras ativadas, permitindo explicar o resultado.

## Cenários de teste

| Umidade | Chuva | Temperatura | Solo | Fase | Resultado esperado |
|---|---|---|---|---|---|
| 20% | não | 25°C | médio | crescimento | Irrigação recomendada (R1, R4) |
| 20% | sim | 25°C | médio | crescimento | Aguardar e reavaliar (R1, R5) |
| 55% | não | 25°C | médio | crescimento | Não irrigar por enquanto (R6) |
| 25% | não | 35°C | arenoso | inicial | Irrigação recomendada + dois alertas (R1, R2, R3, R4) |

## Declaração de ética e limitações

Este é um protótipo **exclusivamente educativo**. Não deve ser utilizado para acionar equipamentos de irrigação nem orientar decisões agronômicas reais sem validação. O limite de 30% e a temperatura de 32°C são **parâmetros didáticos**, não recomendações universais. A necessidade hídrica depende de cultura, solo, estágio fenológico, clima, profundidade e método de medição. A previsão de chuva apenas como sim/não não informa intensidade, horário ou confiabilidade. O programa não coleta nem armazena dados pessoais. O uso em campo exige acompanhamento de profissional habilitado e dados agronômicos apropriados.

## Integrantes

- [Preencher nomes completos]

## Referência inicial

Material fornecido em aula: *Assistente de irrigação da lavoura — Um sistema especialista com 3 regras SE–ENTÃO* (PDF fornecido pelo grupo). O AgroExpert amplia esse exemplo para seis regras didáticas.
